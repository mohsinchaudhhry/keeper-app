import React from "react";

function Note() {
  return (
    <div className="note">
      <h1>Delegation</h1>
      <p>
        Q. How many programmers does it take to screw in a light bulb?
        <br />
        A. None – It’s a hardware problem.
      </p>
    </div>
  );
}

export default Note;
